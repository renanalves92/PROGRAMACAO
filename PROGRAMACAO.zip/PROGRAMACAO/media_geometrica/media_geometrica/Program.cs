﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double valor1, valor2;

        // Solicita ao usuário para inserir os dois valores
        Console.Write("Digite o primeiro valor: ");
        valor1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o segundo valor: ");
        valor2 = Convert.ToDouble(Console.ReadLine());

        // Calcula a média geométrica
        double mediaGeometrica = Math.Sqrt(valor1 * valor2);

        // Exibe a média geométrica calculada
        Console.WriteLine($"A média geométrica dos valores é: {mediaGeometrica}");

        Console.ReadLine(); 
    }
}
