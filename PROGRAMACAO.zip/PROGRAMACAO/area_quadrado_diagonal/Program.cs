﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double diagonalQuadrado;

        // Solicita ao usuário para inserir o valor da diagonal do quadrado
        Console.Write("Digite o valor da diagonal do quadrado: ");
        diagonalQuadrado = Convert.ToDouble(Console.ReadLine());

        // Calcula o lado do quadrado usando o teorema de Pitágoras
        double ladoQuadrado = diagonalQuadrado / Math.Sqrt(2);

        // Calcula a área do quadrado
        double areaQuadrado = Math.Pow(ladoQuadrado, 2);

        // Exibe a área calculada
        Console.WriteLine($"A área do quadrado é: {areaQuadrado}");

        Console.ReadLine(); // Mantém o console aberto até que o usuário pressione uma tecla
    }
}
