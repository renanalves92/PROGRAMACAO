﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double x, y;

        // Solicita ao usuário que insira os valores de X e Y
        Console.Write("Digite o valor de X: ");
        x = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o valor de Y: ");
        y = Convert.ToDouble(Console.ReadLine());

        // Calcula X elevado a Y
        double resultado = Math.Pow(x, y);

        // Exibe o resultado
        Console.WriteLine($"O resultado de {x} elevado a {y} é: {resultado}");

        Console.ReadLine();
    }
}
