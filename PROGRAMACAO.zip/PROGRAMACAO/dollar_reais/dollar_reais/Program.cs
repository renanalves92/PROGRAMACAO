﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double taxaCambio = 5.5; // Exemplo de taxa de câmbio: 1 dólar = 5.5 reais

        // Solicita ao usuário que insira o valor em dólares
        Console.Write("Digite o valor em dólares: ");
        double valorDolares = Convert.ToDouble(Console.ReadLine());

        // Converte o valor em dólares para reais
        double valorReais = valorDolares * taxaCambio;

        // Exibe o valor convertido em reais
        Console.WriteLine($"O valor em reais é: R$ {valorReais}");

        Console.ReadLine(); 

    }
}
