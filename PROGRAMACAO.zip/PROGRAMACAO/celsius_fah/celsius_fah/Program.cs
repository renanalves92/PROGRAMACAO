﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double temperaturaCelsius, temperaturaFahrenheit;

        // Solicita ao usuário que insira a temperatura em Celsius
        Console.Write("Digite a temperatura em Celsius: ");
        temperaturaCelsius = Convert.ToDouble(Console.ReadLine());

        // Converte a temperatura de Celsius para Fahrenheit
        temperaturaFahrenheit = (temperaturaCelsius * 9 / 5) + 32;

        // Exibe o resultado da conversão
        Console.WriteLine($"{temperaturaCelsius} graus Celsius equivalem a {temperaturaFahrenheit} graus Fahrenheit.");

        Console.ReadLine();
    }
}
