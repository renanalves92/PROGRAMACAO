﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double milhasNauticas, quilometros;

        // Solicita ao usuário que insira a distância em milhas náuticas
        Console.Write("Digite a distância em milhas náuticas: ");
        milhasNauticas = Convert.ToDouble(Console.ReadLine());

        // Converte milhas náuticas para quilômetros
        quilometros = milhasNauticas * 1.852;

        // Exibe o resultado da conversão
        Console.WriteLine($"{milhasNauticas} milhas náuticas equivalem a {quilometros} quilômetros.");

        Console.ReadLine(); 
}
