﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double arestaQuadrado;

        // Solicita ao usuário para inserir o valor da aresta do quadrado
        Console.Write("Digite o valor da aresta do quadrado: ");
        arestaQuadrado = Convert.ToDouble(Console.ReadLine());

        // Calcula a área do quadrado
        double areaQuadrado = Math.Pow(arestaQuadrado, 2);

        // Exibe a área calculada
        Console.WriteLine($"A área do quadrado é: {areaQuadrado}");

        Console.ReadLine(); 
    }
}
