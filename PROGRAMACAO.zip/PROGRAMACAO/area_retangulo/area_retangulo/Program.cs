﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double comprimento, largura;

        // Solicita ao usuário para inserir o comprimento do retângulo
        Console.Write("Digite o comprimento do retângulo: ");
        comprimento = Convert.ToDouble(Console.ReadLine());

        // Solicita ao usuário para inserir a largura do retângulo
        Console.Write("Digite a largura do retângulo: ");
        largura = Convert.ToDouble(Console.ReadLine());

        // Calcula a área do retângulo
        double areaRetangulo = comprimento * largura;

        // Exibe a área calculada
        Console.WriteLine($"A área do retângulo é: {areaRetangulo}");

        Console.ReadLine(); 
    }
}
