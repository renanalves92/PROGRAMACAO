﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double num1, num2, num3, num4;

        // Solicita ao usuário para inserir os quatro números
        Console.Write("Digite o primeiro número: ");
        num1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o segundo número: ");
        num2 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o terceiro número: ");
        num3 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o quarto número: ");
        num4 = Convert.ToDouble(Console.ReadLine());

        // Calcula a média aritmética
        double media = (num1 + num2 + num3 + num4) / 4;

        // Exibe a média calculada
        Console.WriteLine($"A média aritmética dos números é: {media}");

        Console.ReadLine(); 
    }
}
