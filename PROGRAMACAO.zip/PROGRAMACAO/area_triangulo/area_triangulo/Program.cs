﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double baseTriangulo, alturaTriangulo;

        // Solicita ao usuário para inserir a base do triângulo
        Console.Write("Digite a base do triângulo: ");
        baseTriangulo = Convert.ToDouble(Console.ReadLine());

        // Solicita ao usuário para inserir a altura do triângulo
        Console.Write("Digite a altura do triângulo: ");
        alturaTriangulo = Convert.ToDouble(Console.ReadLine());

        // Calcula a área do triângulo
        double areaTriangulo = (baseTriangulo * alturaTriangulo) / 2;

        // Exibe a área calculada
        Console.WriteLine($"A área do triângulo é: {areaTriangulo}");

        Console.ReadLine(); 
    }
}
