﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double diametro, raio;

        // Solicita ao usuário que insira o diâmetro do círculo
        Console.Write("Digite o diâmetro do círculo: ");
        diametro = Convert.ToDouble(Console.ReadLine());

        // Calcula o raio do círculo
        raio = diametro / 2;

        // Calcula a área do círculo
        double area = Math.PI * Math.Pow(raio, 2);

        // Exibe o resultado da área calculada
        Console.WriteLine($"A área do círculo é: {area}");

        Console.ReadLine(); 
    }
}
